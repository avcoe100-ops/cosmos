COSMOS — Explore the Universe

Website source: index.html

How to run:
1. Extract this folder if it is zipped.
2. Open index.html in Chrome or Edge.
3. Keep an internet connection enabled because Three.js is loaded from a CDN.

To publish it publicly, upload the folder to a static website hosting service.
